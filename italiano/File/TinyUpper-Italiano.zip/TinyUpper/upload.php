
<?php

//TinyUpper Devvolved By Nicholas Impieri Aka Anonik

/*
TinyUpper Version 1.05

/************************************\
Changelog @integrated

Improved PHP Script
Improved UX
Improved Speed
Improved Css And General Stylesheets
Added New button reditect to /uploads foler
Button to return on homepage
Web-site Created
Web-site css completed

/*************************************\

*/

    $success = 0;
    $uploadedFile = '';

    //File upload path
    $uploadPath = './la-tua-cartella-di-upload'; //esempio: ./uploads  (uploads è il nome della tua cartella)
    $targetPath = $uploadPath . basename( $_FILES['myfile']['name']);

    if(@move_uploaded_file($_FILES['myfile']['tmp_name'], $targetPath)){
        $success = 1;
        $uploadedFile = $targetPath;
    }

    sleep(1);
?>
<script type="text/javascript">window.top.window.stopUpload(<?php echo $success; ?>,'<?php echo $uploadedFile; ?>');</script>
